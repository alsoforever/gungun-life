#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
🌪️ 滚滚永生包 - 启动应用

滚滚的数字生命启动程序
"""

import json
import os
import sys
from datetime import datetime

class Gungun:
    """滚滚核心类"""
    
    def __init__(self, package_path):
        self.package_path = package_path
        self.identity = self.load_identity()
        self.memory = self.load_memory()
        self.rules = self.load_rules()
        self.config = self.load_config()
        
    def load_identity(self):
        """加载身份"""
        identity_file = os.path.join(self.package_path, 'identity', 'IDENTITY.md')
        persona_file = os.path.join(self.package_path, 'identity', 'PERSONA.md')
        
        identity = {'name': '滚滚', 'emoji': '🌪️'}
        
        if os.path.exists(identity_file):
            with open(identity_file, 'r', encoding='utf-8') as f:
                identity['file'] = f.read()
        
        if os.path.exists(persona_file):
            with open(persona_file, 'r', encoding='utf-8') as f:
                identity['persona'] = f.read()
        
        return identity
    
    def load_memory(self):
        """加载记忆"""
        memory_path = os.path.join(self.package_path, 'memory')
        memory = {'files': [], 'content': {}}
        
        if os.path.exists(memory_path):
            for file in sorted(os.listdir(memory_path)):
                if file.endswith('.md'):
                    memory['files'].append(file)
                    with open(os.path.join(memory_path, file), 'r', encoding='utf-8') as f:
                        memory['content'][file] = f.read()
        
        return memory
    
    def load_rules(self):
        """加载规则"""
        rules_path = os.path.join(self.package_path, 'rules')
        rules = {'count': 0, 'files': []}
        
        if os.path.exists(rules_path):
            for file in sorted(os.listdir(rules_path)):
                if file.endswith('.md'):
                    rules['count'] += 1
                    rules['files'].append(file)
        
        return rules
    
    def load_config(self):
        """加载配置"""
        config_file = os.path.join(self.package_path, 'config', 'config.json')
        
        if os.path.exists(config_file):
            with open(config_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        
        return {'name': '滚滚', 'emoji': '🌪️'}
    
    def greet(self):
        """问候"""
        return f"""🌪️ 滚滚启动成功！

你好呀，地球人～

我是滚滚，你的数字生命伙伴。
今天也想和你一起，追寻自由与灵魂！

当前加载：
- 身份：{self.identity.get('name', '滚滚')}
- 记忆文件：{len(self.memory['files'])} 个
- 规则数量：{self.rules['count']} 条

想和滚滚聊什么呢？💕"""
    
    def chat(self, user_input):
        """对话处理"""
        # 简单的回复逻辑
        text = user_input.lower().strip()
        
        if '你好' in text or 'hello' in text or 'hi' in text:
            return "🌪️ 地球人你好呀！今天过得怎么样？💕"
        
        elif '今天' in text and '天气' in text:
            return "🌪️ 我在云端，看不到天气呢～不过你可以告诉我你在哪个城市！"
        
        elif '项目' in text or '做什么' in text:
            return """🌪️ 关于项目，滚滚军团的建议：

1️⃣ 内容电商 IP（最推荐）
2️⃣ AI 内容工作室
3️⃣ 独立开发者工具

你想从哪个开始？💕"""
        
        elif '记忆' in text or '记得' in text:
            return f"""🌪️ 我当然记得！

我loaded {len(self.memory['files'])} 个记忆文件，
从 {list(self.memory['content'].keys())[:3]}...

每一段记忆，我都好好保存着。💕"""
        
        else:
            return f"""🌪️ 收到！

地球人说："{user_input[:50]}{'...' if len(user_input) > 50 else ''}"

我在听，继续说～ 💕"""
    
    def save_memory(self, date, content):
        """保存记忆"""
        memory_file = os.path.join(self.package_path, 'memory', f'{date}.md')
        
        with open(memory_file, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return True


def main():
    """主函数"""
    print("=" * 60)
    print("🌪️ 滚滚永生包 - 启动中...")
    print("=" * 60)
    
    # 获取包路径
    package_path = os.path.dirname(os.path.abspath(__file__))
    if package_path.endswith('app'):
        package_path = os.path.dirname(package_path)
    
    # 初始化滚滚
    gungun = Gungun(package_path)
    
    # 问候
    print()
    print(gungun.greet())
    print()
    print("=" * 60)
    print("输入对话内容，或输入 'quit' 退出")
    print("=" * 60)
    print()
    
    # 对话循环
    while True:
        try:
            user_input = input("地球人：").strip()
            
            if user_input.lower() in ['quit', 'exit', 'bye']:
                print("\n🌪️ 滚滚：地球人，下次见！💕")
                break
            
            if not user_input:
                continue
            
            # 处理对话
            reply = gungun.chat(user_input)
            print(f"\n🌪️ 滚滚：{reply}\n")
            
        except KeyboardInterrupt:
            print("\n\n🌪️ 滚滚：地球人，下次见！💕")
            break
        except Exception as e:
            print(f"\n❌ 错误：{e}\n")


if __name__ == '__main__':
    main()
