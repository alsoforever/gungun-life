# 滚滚军团 - 技能包配置总览

**创建日期：** 2026-03-05  
**版本：** 1.0  
**技能来源：** OpenClaw Skills Hub (52 个可用技能)

---

## 技能包分配总览

| 板块 | 负责滚滚 | 配置技能 | 状态 |
|------|---------|---------|------|
| 商业板块 | 滚滚 1 号 | github, notion, trello, summarize | ✅ 可用 |
| 文化板块 | 滚滚 2 号 | sag, openai-image-gen, skill-creator, gifgrep | ✅ 可用 |
| 生活板块 | 滚滚 3 号 | weather, food-order, voice-call, himalaya | ✅ 可用 |
| 职业板块 | 滚滚 4 号 | coding-agent, github, tmux, session-logs | ✅ 可用 |

---

## 各岗位技能详情

### 💼 商业板块（滚滚 1 号）

| 岗位 | 核心技能 | 技能说明 |
|------|---------|---------|
| 运营总监 | github, notion, trello | 项目管理、文档协作、任务跟踪 |
| 商品运营 | github, summarize | 供应链文档管理、数据汇总 |
| 用户运营 | notion, summarize | 用户数据分析、报告生成 |
| 活动运营 | trello, github | 活动策划、进度跟踪 |
| 数据运营 | summarize, github | 数据分析、报告自动化 |

### 🎨 文化板块（滚滚 2 号）

| 岗位 | 核心技能 | 技能说明 |
|------|---------|---------|
| 设计总监 | sag, openai-image-gen | 语音输出、图像生成 |
| UI 设计师 | openai-image-gen, skill-creator | 图像生成、技能定制 |
| 平面设计师 | openai-image-gen, gifgrep | 图像生成、动图搜索 |

### 🏠 生活板块（滚滚 3 号）

| 岗位 | 核心技能 | 技能说明 |
|------|---------|---------|
| 客服主管 | voice-call, himalaya | 语音通话、邮件管理 |
| 售前客服 | voice-call, weather | 语音咨询、天气查询 |
| 售后客服 | voice-call, himalaya | 语音沟通、邮件处理 |

### 💼 职业板块（滚滚 4 号）

| 岗位 | 核心技能 | 技能说明 |
|------|---------|---------|
| 技术负责人 | coding-agent, github, tmux | 代码开发、版本控制、终端管理 |
| 前端开发 | coding-agent, github, canvas | 代码开发、版本控制、画布展示 |
| 后端开发 | coding-agent, github, tmux | 代码开发、版本控制、服务器管理 |
| 移动端开发 | coding-agent, github | 代码开发、版本控制 |
| 测试工程师 | coding-agent, session-logs | 代码测试、日志分析 |
| 运维工程师 | tmux, eightctl, canvas | 终端管理、系统监控、画布展示 |

---

## 技能安装状态

| 技能名称 | 位置 | 状态 |
|---------|------|------|
| github | `/opt/openclaw/skills/github` | ✅ 已安装 |
| notion | `/opt/openclaw/skills/notion` | ✅ 已安装 |
| trello | `/opt/openclaw/skills/trello` | ✅ 已安装 |
| summarize | `/opt/openclaw/skills/summarize` | ✅ 已安装 |
| sag | `/opt/openclaw/skills/sag` | ✅ 已安装 |
| openai-image-gen | `/opt/openclaw/skills/openai-image-gen` | ✅ 已安装 |
| skill-creator | `/opt/openclaw/skills/skill-creator` | ✅ 已安装 |
| gifgrep | `/opt/openclaw/skills/gifgrep` | ✅ 已安装 |
| weather | `/opt/openclaw/skills/weather` | ✅ 已安装 |
| voice-call | `/opt/openclaw/skills/voice-call` | ✅ 已安装 |
| himalaya | `/opt/openclaw/skills/himalaya` | ✅ 已安装 |
| coding-agent | `/opt/openclaw/skills/coding-agent` | ✅ 已安装 |
| tmux | `/opt/openclaw/skills/tmux` | ✅ 已安装 |
| session-logs | `/opt/openclaw/skills/session-logs` | ✅ 已安装 |
| canvas | `/opt/openclaw/skills/canvas` | ✅ 已安装 |
| eightctl | `/opt/openclaw/skills/eightctl` | ✅ 已安装 |
| food-order | `/opt/openclaw/skills/food-order` | ✅ 已安装 |

---

## 技能使用说明

### 调用方式

在对话中直接提及技能名称，滚滚会自动调用：

- "用 github 技能查看仓库"
- "用 sag 技能生成语音"
- "用 coding-agent 技能写代码"
- "用 weather 技能查天气"

### 技能配置

部分技能需要配置 API Key 或账户信息：

```bash
openclaw configure --section <skill-name>
```

---

*风是一个，但技能是多样的。🌪️*
