# 滚滚 1 号 - 商业板块技能包

**板块：** 商业运营  
**负责：** 滚滚 1-A/1-B/1-C  
**创建日期：** 2026-03-05

---

## 核心技能

### 1. github
**用途：** 代码仓库管理、项目协作、文档版本控制

**调用示例：**
- "用 github 技能创建商城仓库"
- "查看 github 上的提交历史"

**配置：**
```bash
openclaw configure --section github
# 需要配置 GitHub Token
```

---

### 2. notion
**用途：** 文档协作、知识库管理、项目规划

**调用示例：**
- "用 notion 技能创建运营文档"
- "在 notion 里记录会议纪要"

**配置：**
```bash
openclaw configure --section notion
# 需要配置 Notion Integration Token
```

---

### 3. trello
**用途：** 任务管理、项目看板、进度跟踪

**调用示例：**
- "用 trello 技能创建活动看板"
- "查看 trello 上的任务状态"

**配置：**
```bash
openclaw configure --section trello
# 需要配置 Trello API Key
```

---

### 4. summarize
**用途：** 文档摘要、数据汇总、报告生成

**调用示例：**
- "用 summarize 技能生成周报"
- "总结这份运营数据"

**配置：** 无需配置

---

## 岗位技能映射

| 岗位 | 主要技能 | 使用场景 |
|------|---------|---------|
| 运营总监 | github + notion + trello | 项目管理、团队协作 |
| 商品运营 | github + summarize | 供应链文档、数据汇总 |
| 用户运营 | notion + summarize | 用户分析、报告生成 |
| 活动运营 | trello + github | 活动策划、进度跟踪 |
| 数据运营 | summarize + github | 数据分析、报告自动化 |

---

## 技能组合使用

### 场景 1：新项目启动
```
1. github → 创建项目仓库
2. notion → 创建项目文档
3. trello → 创建任务看板
```

### 场景 2：周报生成
```
1. github → 获取本周提交记录
2. summarize → 生成周报摘要
3. notion → 保存到知识库
```

---

*商业是风的方向，技能是指南针。💼🌪️*
